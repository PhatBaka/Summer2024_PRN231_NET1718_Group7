﻿namespace WebApplication3.Enum
{
    public enum RoleEnum
    {
        ADMIN,
        STAFF,
        CUSTOMER
    }
}
